module.exports = {
  plugins: {},
}
